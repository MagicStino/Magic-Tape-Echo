# Plugin catalog: design and roadmap

Goal: one public, browsable list of open-source MPC/Force VST plugins with their current version, download link,
checksum and device-verification status, that stays correct without anyone editing it by hand.

## Principles (what keeps it low maintenance)
1. **No server, no database, no accounts.** A static site on GitHub Pages, built from one generated `catalog.json`.
2. **Authors register once, never per release.** A plugin's catalog entry is a tiny file pointing at its GitHub repo.
   Versions, URLs and checksums are *discovered* from the repo's Releases by a scheduled job.
3. **The zip is the source of truth, not the registry.** Every release zip carries a machine-readable manifest
   written by `tools/release.py`. The catalog reads and validates it; nobody types a version number.
4. **Automatic on updates, human only on first entry.** A new plugin needs one reviewed PR. Later releases are
   picked up and validated by CI; a failed validation hides that version and opens an issue on this catalog repo (not when a newer release
   of that plugin passes; see `tools/catalog_issues.py`).
5. **Installers execute as root on someone's device.** So: open source only, checksums shown, canonical
   `install.sh` checked, previous versions kept, a maintainer can yank a version.
6. **No other company's branding.** Listed skins, screenshots and plugin names carry no manufacturer names or logos
   (rule added 2026-10-12 after LXRXXL, #290, was delisted for it). See `catalog/README.md` "Skins and branding".
6. **The catalog never hosts or links a build that contains someone else's firmware.** A port whose DSP is compiled
   from the user's own firmware cannot publish a zip, so it lists as **build-yourself** (below): open source, no
   download, no checksum, a build command and the user's own files it needs. This is a separate distribution type;
   the checks for normal `release` entries are unchanged.

## Architecture
```
plugin repo (author)            catalog repo (community)              consumers
-----------------------         ---------------------------           ---------------------
vst.json + build.sh             plugins/<id>.json  (registry, PR)     website (Pages)
vst-release.yml  --release-->   nightly + on-dispatch workflow:       device script / desktop app
  zip + mpc-plugin.json           fetch releases -> download zip ->     read catalog.json
  (draft, tested, published)      validate -> catalog.json + site
```

### Registry entry (`plugins/<id>.json`, hand-written once)
`id`, `name`, `author`, `repo` (owner/name), `kind` (instrument | effect), `license`, `summary`, `screenshot`
(optional `https://` URL; the site ignores anything else), `asset_pattern` (default `*-mpc-armv7.zip`), `homepage` (optional),
`tier` (optional, only `"experimental"`) and `featured` (optional bool); see Trust tiers below. `flags_reviewed` (optional list of
risky-call categories a maintainer has looked at, e.g. `["network"]` for a remote-control plugin; see Validation). Nothing versioned.

Length limits (checked by `tools/catalog_build.py`): `summary` at most 350 characters and `tags` at most 8, so cards and the page stay
readable. Put the full feature list in the repo README. Maintainers may edit a summary or tags for length and consistency, but do not
change claims about testing or safety without the author.

### Distribution types
`distribution` in the registry entry: `release` (default; everything above) or `build-yourself`.

A **build-yourself** plugin's build embeds firmware-derived code or data (for example the DSP statically recompiled from
the user's own Elektron OS file, plus ROM samples), so the built `.so` and its installer zip can never be published
without breaking the "no closed binaries or copyrighted ROMs" rule. The source is open (an SPDX open licence is
required; `source_available` is not accepted) and the repo ships a one-command build script that makes a personal
installer. What the catalog holds instead of a download:
- `requires_user_files`: the user's own files the build needs (`name`, `description`), non-empty.
- `build`: `command` (shown verbatim), `script` (its path in the repo), `docs_url` (`{tag}` becomes the shown version's
  git tag) and `needs` (tools, e.g. Docker).
- `components` (optional): the plugins one build installs (`id`, `name`, `kind`, `uid`), because one repo may install
  several (Monomodule One and FX). The kind filter matches any component.
- **Versions are git tags** `vX.Y.Z`, not release assets. The newest is `latest`. A tag counts only if the build script
  exists at that tag; an older tag without it is skipped quietly (tags are never moved) and only the newest tag missing
  it is reported. There is no zip, no sha256 and no `catalog_check.py`; `tested.json` is still read.
- **Guardrails** (`tools/catalog_build.py`): the repo must be readable; the licence must be open; `requires_user_files`
  must be non-empty; at least one valid tag must contain the script; and any GitHub release carrying a
  `*-mpc-armv7.zip` asset is reported loudly in `problems.json` (and so as a catalog issue), because publishing a built
  zip would break the licence position. The entry stays listed while that is fixed.
- **Site:** a "Build it yourself" badge, a box with the user's own files and the exact command, the tested-on line,
  and a fixed warning: the result contains firmware-derived data, build it yourself, install it on your own devices only,
  never share it. No download button, no checksum.

### Trust tiers (2026-10-10, offline: unit tests and a headless-browser check, not yet published)
Open registration plus bulk ports means the catalog needs a way to say how much to trust an entry, without gatekeeping who may
list. Each plugin gets a `tier` in `catalog.json`, computed by `catalog_build.py` (`tier_of`) from evidence, never typed:
`verified` (the newest stable, unyanked version has a `tested.json` entry), `listed` (valid release, no recorded test) or
`experimental` (no stable release, or the registry entry says `"tier": "experimental"`). The registry may only cap a tier
(`"tier"` accepts only `"experimental"`); `"featured": true` is a maintainer pick, ignored while experimental. The site hides
Experimental by default (the Tier filter and a "Show them" link reveal it), badges Verified and Experimental cards only (2026-10-11:
Listed is the unlabelled middle, still computed and filterable as "Not yet verified"), and the default sort,
"Recommended", is featured, then tier, then (2026-10-14, offline) Verified on both generations before one, newest hardware-test
date, downloads, and finally name. Verified is split by device generation (2026-10-12, offline: unit tests and a
headless-browser check): `verified_on` in `catalog.json` lists `gen1` and/or `gen2` (`verified_on` in `catalog_build.py`). A `tested.json`
entry whose `device` names Gen2 counts for `gen2`, and only when that version has an aarch64 build; any other entry counts for `gen1`.
The card shows one badge per generation ("Verified Gen1", "Verified Gen2"), the Tier filter has "Verified on Gen1" and
"Verified on Gen2", and the quality bar asks for a Gen2 test (`tested-gen2`) when a Gen2 build has none. The tier itself stays one
value (verified on either generation), so the sort is unchanged. Catalogs built before the field read a verified plugin as Gen1. Catalogs built before the field read as `listed`. Deliberately not done:
star ratings, comments, upvotes (few users, needs a backend and moderation; if wanted later, compatibility reports through
GitHub Discussions that feed `tested.json` fit the static model better, with any vote count only a tiebreaker inside a tier).

### Quality bar (2026-10-10, offline: unit tests and a headless-browser check)
`catalog_build.py` lists, per plugin, the bar items it does not meet yet (`bar_missing`, texts in `catalog.json` `bar`; `BAR` and
`bar_of`): no stable release, no screenshot, no skin, CPU verdict FAIL, no CPU bench figure, no `tested.json` entry for the newest
release. The card shows them in a collapsed "To improve this listing". Informational only: it changes no tier and hides nothing.
The build log prints how many plugins miss each item. Plan and next steps: `docs/CATALOG_QUALITY.md`.

### Zip manifest (`mpc-plugin.json`, generated by `release.py`)
`schema`, `id`, `uid` (VST uid), `name`, `version`, `so` file, `skin` dir, `kind`, `armv7`, `max_glibc`, `cpu`
(bench verdict), `requires` (firmware/MockbaMod notes), `source_repo`, `license`, `param_compat` (the X in X.Y.Z:
bumping it breaks saved projects), `sha256` of every file. `INSTALL.md` stays for humans.

### Gen2 (aarch64)
A version may also have a `*-mpc-aarch64.zip` on the same release (arch `aarch64`, same id/uid/version). It is listed under the same
registry entry as `versions[].assets.aarch64` with `gen2: true`; `url`/`sha256` stay the armv7 asset. `catalog.tsv` carries the aarch64 zip in three trailing columns (size, sha256, url). See [GEN2.md](GEN2.md).

### Generated `catalog.json`
Per plugin (`distribution: release`): registry fields + `versions[]` (newest first, last N kept): `version`, `date`, `url`, `size`, `sha256`,
`channel` (stable, or beta for GitHub prereleases), `notes` (release body), `param_compat`, `yanked`,
`tested[]` (device, firmware, date; from an optional `tested.json` in the plugin repo or the release notes).
Versioned schema (`"schema": 1`) so the site and installers can evolve without breaking old clients.

### Validation (CI, per new version)
Zip layout matches the spec; manifest matches the registry (`id`, `uid`, repo); `.so` is ARM ELF with
GLIBC <= 2.36 (above 2.32 it is listed as MPC OS 3.x only); `install.sh`/`uninstall.sh`/`plugin_list.awk` are identical to this repo's canonical copies (or a
diff is flagged for manual review); checksums match; `uid` and `file=` name don't collide with any other catalog
entry; license file present. This reuses code already in `tools/release.py`.
Risky calls (2026-10-11, offline: `tools/test_catalog.py`): every ELF file in the zip has its imported functions read from
its dynamic symbol table (`RISKY_CALLS` in `tools/catalog_check.py`): network, running programs, loading code at runtime, changing the
system. A hit is a warning and a `flags` field on the version record, never a rejection: a person looks, or the author explains.
`dlopen` on its own is not flagged (toolchains import it); next to other calls it is.
It sees only what the file imports, so a determined author can hide a call; it catches the careless case, not a skilled one.
The nightly build re-checks every kept version and writes `flags.json` next to `problems.json`: the newest stable version of
each plugin, less the categories in its entry's `flags_reviewed`. `tools/catalog_issues.py` opens one issue per plugin and set of
categories ("Catalog: <id> flagged for review (network, runs programs)"). Closing it is the review: it is never reopened, a later
version with the same categories opens nothing, new categories open a new issue (2026-10-11, offline tests only; the first run
opened one issue per version, 70 in all, which this replaced).

### Site
Generated static HTML (`tools/catalog_site.py`, no JS framework): searchable/filterable grid, a page per plugin
(screenshot, description, version history, install steps, source link, checksum, tested-on), a "recently updated"
feed and an Atom feed. Fast-moving plugins are handled by the version list and the stable/beta channel split.

### Installer / updater (later, optional)
Same JSON, thin clients: (a) a BusyBox shell script on the device (`list`, `install <id>`, `update`, `remove`)
if the device has a usable `wget`/`curl` + TLS (**unverified: check on hardware first**); (b) a desktop helper that
downloads and pushes over SSH, like Schwung's. Both must: verify sha256, show the source link, warn on a
`param_compat` bump, and reuse the zip's own `install.sh` so there is one install path.

## Prior art: Schwung (reviewed 2026-09-29, `charlesvestal/schwung`)
- **Catalog** is one hand-edited `module-catalog.json` in the host repo (`catalog_version: 2`): a `host` block with
  channels, a `taxonomy` (component types, subcategories, tags), and ~146 module entries with only `id`, `name`,
  `description`, `author`, `component_type`, `subcategory`, `tags`, `github_repo`, `default_branch`, `asset_name`,
  `min_host_version`, `requires`. **No versions or checksums in the catalog**: clients resolve the latest GitHub
  release of `github_repo` and fetch `asset_name`. This confirms the "register once, discover versions" model.
- **Site** (`schwung-catalog-site`, planned in `docs/plans/2026-03-28-catalog-site-design.md`): static GitHub
  Pages, no framework; a daily + on-push Action fetches the catalog and GitHub download counts into `data/*.json`
  and commits them. Sort by popular/newest/A-Z, category tabs, cards with audio previews.
- **Installers:** a Tauri (Rust + web UI) desktop app that finds the device, sets up SSH, downloads the host
  tarball and chosen modules and deploys with scp; plus an on-device Go web manager (`schwung-manager`) that
  refreshes the catalog and updates modules. Not Electron, despite the chat.
- **Take:** copy the taxonomy idea (kind, subcategory, tags), download counts, and `min_host_version` (ours: min
  MPC OS version / MockbaMod). Where we go further: checksums and a validated manifest, because our installer runs
  as root and edits `MPC.settings`. Our catalog is per-plugin files (PR-friendly, no merge conflicts) instead of
  one big JSON.

## Roadmap
Each phase is independently useful. Phases 0 to 3 are doable in this repo; the catalog can live under `catalog/`
here first and move to its own repo (recommended, for community ownership) once the format settles.

### Phase 0: Decide (needs the user)
- [x] Catalog home: `catalog/` in this repo (decided 2026-09-29; can be split out later). Hosting: GitHub Pages.
- [ ] Naming and domain (a `github.io` URL is fine to start).
- [x] Inclusion policy: open-source licence, or public source flagged `source_available` and shown with a Restricted use badge (JV-880's MAME licence; decided 2026-09-29) (SPDX list in `tools/catalog_build.py`), armv7 zip, no closed binaries (decided 2026-09-29).
- [ ] Ask early adopters which plugins exist today and which already publish GitHub releases.

### Phase 1: Make every release self-describing
- [x] Portable paths (2026-09-29; device-tested on a Force, `docs/PORTABLE_TEST.md`): `wrapper/plugin_dir.h` (since 2026-10-01 `/proc/self/maps` only: `dladdr()` binds to GLIBC_2.34, which MPC OS 2.x cannot load) so
      engines locate presets/assets next to the `.so` wherever it was loaded from (`/sdcard`, `/media/*/Synths`, ...).
      `install.sh`/`uninstall.sh`/`gen_vst.py` take the target dir from a variable or detect it. Reconcile with
      Locrian's `plugin-meta` export (need to see the file).
- [x] Spec: `docs/CATALOG_SPEC.md` (registry entry, manifest, catalog.json, channels), schema 1 (2026-09-29). JSON Schema files still to do.
- [x] `tools/release.py` emits `mpc-plugin.json` (`--id/--repo/--license/--requires`); checksums include it (2026-09-29).
- [x] `tools/catalog_check.py <zip>` and `tools/test_catalog.py` (2026-09-29).
- [x] `vst-release.yml` runs the validator; new inputs `plugin_id`, `license`, `requires` (2026-09-29; runs in CI on every port release).
- [ ] Port template repo (`vst.json`, `build.sh`, release workflow, `tested.json` stub, README) so a new plugin is
      catalog-ready from its first commit. Document in `PORTING.md`.
- [x] Back-fill (2026-10-02): the existing ports have catalog-conformant releases (portable layout, glibc 2.31): Acid 1.0.3, Crate Digger 1.1.5, Dexed (DX7) 1.0.4, JV-880 1.0.5, Maze Voice 1.0.1, Maze Sequencer 1.0.1 (its 1.0.0 is kept as a pre-release, MPC OS 3.x only), each device-tested on a Force before publishing. Euclidier is parked (0.5.0 spawns the MockbaMod add-on binary) and not listed.

### Phase 2: The catalog builder
- [x] (2026-09-29; runs against real releases, checked 2026-10-02) `tools/catalog_build.py`: read `plugins/*.json`, list GitHub releases (API, token via Actions), download
      matching assets, validate, write `catalog.json` + `catalog.schema.json`. Idempotent and cached by asset id.
- [x] (2026-10-03, offline tests and a dry run against the live registry) Failure handling: bad version excluded,
      previous good version kept, one issue per failing release on this repo (`tools/catalog_issues.py`). A failure
      that a newer passing, unyanked release supersedes gets no issue (an old tag can't be rebuilt); an open issue
      closes itself when its problem is gone or superseded; a closed per-tag title is never reopened (a tag can't
      be rebuilt, even if its release asset is later replaced); a closed "repo cannot be read" title reopens if the
      repo breaks again, since that one isn't tied to a fixed tag; duplicates close. Issues on the plugin's own
      repo: not done.
- [x] (`.github/workflows/catalog.yml`, builds and uploads an artifact; Pages deploy comes with Phase 3) Workflow: nightly cron + `repository_dispatch`/`workflow_dispatch`; an optional one-line "ping" step ports
      can add to their release workflow for instant updates.
- [x] (registry rules and licence list; 'latest release validates' runs in the full build) PR check for registry PRs: schema, repo exists, latest release validates, uid unique. Issue template
      "Add my plugin".
- [x] `catalog/yanked.json` mechanism for pulling a bad release without touching the author's repo.

### Phase 3: The website
- [x] `tools/catalog_site.py` generates the site from `catalog.json`; `catalog.yml` deploys with Pages on main (2026-09-29; checked in headless Chromium; Pages deploy live at https://sd88me.github.io/mpc-vst-plugins/).
- [x] List with search, filters (kind, style, developer, license, MPC OS 2.x / 3.x, beta) and sorting (updated, downloads, name, developer, kind), state kept in the URL hash; plugin page with history, install steps, checksum, source link.
- [x] Guide pages Install, Build and Workflow (Add yours was merged into Workflow on 2026-10-09; add.html redirects) (2026-09-29): Markdown in `catalog/pages/*.md`, rendered by `tools/catalog_site.py`
      with a shared menu; checked in headless Chromium at desktop and phone width.
- [x] (2026-09-29; live, `feed.xml` and `catalog.tsv` both served, checked 2026-10-02) Atom feed `feed.xml`; "Tested on" from optional `tested.json` in the plugin repo; contributor docs in `catalog/README.md`.
- [x] (2026-10-03) `catalog/patches.json`, the device patches the installer app lists in its read-only step 7, is validated by `tools/patch_check.py` and published by `tools/catalog_site.py` next to `catalog.json` (`docs/PATCHES.md`).
- [x] (2026-10-09, offline: browser-checked at desktop and phone width, not yet published) The catalog page has tabs: All, Instruments, MIDI, Effects and Addins (2026-10-10; All is every plugin together; since 2026-10-14, offline, All is the first tab and the landing tab, so a link without `tab=` opens on All and an Instruments link carries `#tab=instrument`: MIDI is the optional registry field `role: "midi"`, tagged by hand on 14 sequencers/generators and listed there instead of under Instruments; the other tabs are the old single Plugins tab split by kind; they share the filter bar and grid, a bundle shows under each kind it installs, old `#tab=plugins` links open Instruments), Device patches (the `patches.html` cards) and
      Companion apps (`catalog/apps.json`, `tools/app_check.py`; issue #232, MPC Link first). The tab is in the URL hash (`#tab=apps`). The site is named "Open MPC - Plugin Catalog" and the footer links the Discord.
- [x] (2026-10-09, tested offline against MPC Link v0.4.0 and a fake GitHub; the first nightly run is unverified) Companion app downloads are read from each app's newest stable GitHub release by `tools/app_resolve.py` (`assets` rules in `catalog/apps.json`), run by `catalog.yml`; pinned `downloads` are the fallback.
- [ ] Announce to the community; collect what people actually ask for before building Phase 4.

### Distribution: build-yourself (2026-09-29)
- [x] Registry `distribution`, `requires_user_files`, `build`, `components`; tag-based versions; guardrails; site card;
      tests (`BuildYourselfTest`); entries for `monomodule` and `machinedrum-module`. Unit-tested with a fake GitHub only.
- [x] First real run (2026-10-02): the catalog lists Monomodule (0.10.2 and earlier tags) and Machinemodule (0.3.6 and earlier) from their `vX.Y.Z` tags on `main`, with "Tested on" from each repo's `tested.json`. A new version appears after pushing a tag on `main` that contains the build script and the next catalog build.
- [x] Installer/updater (Phase 4) skip `build-yourself` entries: nothing to download or install (they are not in `catalog.tsv`; the desktop app takes their built zips by drop).

### Layout migration: one self-contained folder per plugin (started 2026-09-29)
Locrian's installer uses a drop-in folder in `Synths` (`docs/CATALOG_SPEC.md`, "Portable layout"). Goal: make it our only layout.
- [x] `release.py` writes `portable/<skin>/`; `catalog_check.py` verifies it; the installer is tested against a copy of `MPC.settings`.
- [x] Device test passes (`docs/PORTABLE_TEST.md`; Dexed on a Force, 2026-09-29): loads from `/sdcard/Synths/<skin>/` and from a USB stick,
      upgrades an old install without duplicating, keeps user files, uninstalls cleanly. Results in `docs/NOTES.md`.
- [x] Ports stop hardcoding `/sdcard/...` and use `MODULE_SUBDIR`: Dexed, JV-880 and Monomodule done (their old-layout installs still
      resolve to the same folder); Crate Digger already used `dladdr`; `gen_vst.py` warns about a fixed path.
- [x] The portable folder is the only layout (2026-09-29): `install.sh` / `uninstall.sh` are the portable installers (they also move an
      old `/sdcard/vst` install and its user files over), the duplicate `payload/` and `plugin.xml` are gone, the manifest has
      `layout: "portable"`; `catalog_check.py` still accepts old-layout zips so earlier releases stay listed.
- [x] Monomodule (2026-09-30): `release/package.sh` builds two `release.py` packages (One and FX; both carry the user's OS file, One's
      `monomodule/dumps` is user data) plus a top-level installer that runs both. 0.9.2 verified on a Force (sound, presets); tag v0.9.2.
- [x] Re-release the current plugins in the new layout and test on a device (done 2026-10-02, verified on a Force): Dexed 1.0.4, JV-880 1.0.5, Acid 1.0.3, Crate Digger 1.1.5, Maze Voice 1.0.1, Maze Sequencer 1.0.1; Monomodule 0.10.2 and Machinemodule 0.3.6 are build-yourself (per-user builds go through `release.py`, so they are portable). Euclidier stays parked.
- [x] Guides (Install, Build, Workflow; Setup was merged into Build on 2026-10-01) checked against the new layout (2026-09-30): Install's manual steps use `plugin-meta.xml`,
      and it has "If a plugin disappears after a restart". Site cards carry no layout-specific text (`index.template.html`).
- [x] Old-layout releases are flagged (2026-10-13, offline: `tools/test_catalog.py`): warning in `catalog_check.py`, a builder problem for a newest stable release, and a PR check (`--require-portable`) for new or changed registry entries. Prompted by a third-party port whose release zip still used `/sdcard/vst` and did not show up in plugin managers.
- [x] Stray registry files are rejected (2026-10-15, offline: `tools/test_catalog.py`): `--check-registry` fails on any `*.json` directly in `catalog/` other than `apps.json`, `patches.json` and `yanked.json`. The build only reads `catalog/plugins/*.json`, so an entry added one folder too high (GitHub's "Create file" in `catalog/`) used to pass CI and never be listed (Fretty, #447).
- [x] Published releases still in the old layout dropped off a list-rebuilding scanner (NOTES 2026-09-30); all current plugins were re-released above, so the scanner and the catalog agree.

### Phase 4: Install and update from the device or desktop
- [x] Hardware check (2026-09-30, Force, NOTES.md): `wget` 1.20.3 and `curl` fetch HTTPS from GitHub and this site; `/tmp` is a 1 GB tmpfs.
- [x] `tools/mpc-store.sh` (BusyBox `sh`): `list`, `install <id[@ver]>...`, `update`, `remove`, `sync`; downloads and checks every zip's sha256
      from `catalog.tsv` before touching the device, stops MPC once, runs each zip's own `install.sh -y -n`, starts MPC once, remembers
      what it installed in `<synths>/.mpc-store`; holds back a major (`param_compat`) update unless `--major`; `--dry-run`; never
      restarts MPC without a confirmation (`-y` to skip). `catalog.tsv` (shell-friendly index of the downloadable plugins) and the
      helpers `mpc-store.sh`, `sync.sh`, `plugin_list.awk` (hash-checked against the index) are published next to `catalog.json` by
      `tools/catalog_site.py`. Build-yourself plugins are not in it. Tested offline against a local server (BusyBox) and, dry-run, on a Force.
- [x] (2026-09-30) Catalog page that builds the one-line command (`ssh -t root@<ip> "wget -qO /tmp/mpc-store.sh <site>/mpc-store.sh && sh /tmp/mpc-store.sh install acid jv-880"`: download, then run, not piped into `sh`, so the confirmation prompts can read the keyboard), with the script
      text and a "download and review first" version. Ticks on the cards, IP box, copy button, the review steps with the script's sha256; the
      selection lives in the link (`#sel=acid,jv-880`); `tools/catalog_site/browser_test.py` (Playwright in the html_art image) covers it.
- [x] (2026-10-12) Screenshot popup: a card's `screenshot` sits at the top of the card (cropped to 2:1, a dead link drops the frame); clicking
      it opens the whole card over a dark backdrop with the picture uncropped. The popup has its own link, `#p=<id>` added to the page's
      hash (ids are stable); a link without `tab=` opens on the plugin's tab. Escape, Back, the backdrop and × close it. Same browser test.
- [x] (2026-10-13) Share links: `catalog_site.py` writes `p/<id>.html` per plugin with the card's Open Graph and Twitter tags (title,
      summary, screenshot), since link previews read neither the `#p=` hash nor JS. The page sends a browser on to `index.html#p=<id>` by
      script (no meta refresh: Facebook's crawler would follow it). The popup's "Copy link" button, the card's title and its screenshot all
      link there; the title opens the popup on cards without a screenshot too.
- [x] Desktop helper (2026-09-30): `tools/desktop` (Go, one static binary per OS, one dependency): a local web page on 127.0.0.1 behind a random
      token; connect over SSH, pick catalog plugins and/or drop release zips (build-yourself ones too), install with one MPC stop/start;
      catalog downloads checked against the catalog's sha256; tar stream keeps modes/symlinks; older installers (no `-n`) run first
      with their own restart. Go tests with an in-process fake SSH device (race detector) and a browser test against a stand-in device.
      Unsigned binaries (first-run warnings documented). Release: workflow "Desktop installer" (draft release, then publish); v0.3.1 published 2026-10-01.
      Also removes plugins it can identify (catalog or a dropped zip), keeping the manifest's `user_data` (step 4 on the page), and prunes old
      `MPC.settings.bak-*` backups (step 5; `mpc-store.sh prune`). The catalog records per version whether the installer understands `-n`
      (`defer`), so the app states the exact restart count; `mpc-store.sh` runs an older installer by itself instead of passing it `-n`.
- [ ] Update notices honour `param_compat` (a major bump warns that saved projects will change).

### Addins (2026-10-02)
- [x] Libraries MPC preloads are a catalog kind (`addin`, `docs/ADDINS.md`): the shared LD_PRELOAD installer lives in
      `tools/release/addin` (tested with sh and BusyBox, `tools/test_addin.sh`), `tools/release_addin.py` packages an addin,
      `catalog_check.py` validates it, the registry, `catalog.tsv` and the site list it, and `mpc-store.sh` and the desktop app
      install, update and remove addins in the same single MPC restart as plugins.
- [x] Device test of released addins through the zip, `mpc-store.sh` and the desktop app (NOTES.md 2026-10-03).

### Phase 5: Nice to have
- [ ] Automated screenshot generation of every skin page from the zip (reuses `studio.py preview`).
- [ ] Skin-only and preset-pack entries (`kind: skin | presets`).
- [ ] Other architectures/devices if MPC OS variants appear; `catalog.json` already carries `armv7` explicitly.
- [ ] Optional signed manifests (minisign) if the community wants stronger provenance than HTTPS + sha256.

## Risks and open questions
- **Root install of third-party binaries.** Mitigated by open-source-only, canonical installer check, visible
  checksums and yanking. State clearly on the site that everything is community-provided.
  Done (2026-10-11): the catalog footer and the installer app's connect step say community-provided, root, at your own risk,
  no warranty, back up first, not affiliated with Akai. What Verified means (a hardware test, not a security review)
  is explained on the install page and in the README, not on every page.
- **Non-GitHub hosting.** Start GitHub-only; the registry's `repo` field can grow a `releases_url` later.
- **Authors not using `release.py`.** Support them by documenting the manifest; the validator is the contract.
- **Rate limits / token.** One nightly run with the Actions token is far below limits for hundreds of plugins.
- **Catalog scope creep.** Every feature that needs a server, a DB or manual curation is out of scope by default.
