#include <initializer_list>
#include "../src/vst2.hpp"
#include <dlfcn.h>
#include <cassert>
#include <cmath>
#include <cstdio>
int main(int argc,char**argv){assert(argc==3);void*a=dlopen(argv[1],RTLD_NOW),*b=dlopen(argv[2],RTLD_NOW);assert(a&&b);
 auto makeA=(AEffect*(*)(audioMasterCallback))dlsym(a,"VSTPluginMain");auto makeB=(AEffect*(*)(audioMasterCallback))dlsym(b,"VSTPluginMain");
 for(int mode:{0,10}){auto*x=makeA(nullptr);auto*y=makeB(nullptr);for(auto*e:{x,y}){e->setParameter(e,4,mode/11.f);e->setParameter(e,5,mode?.5f:0);e->dispatcher(e,12,0,1,nullptr,0);}
 float l[128],r[128],al[128],ar[128],bl[128],br[128];float*in[]={l,r},*oa[]={al,ar},*ob[]={bl,br};double max=0;
 for(int k=0;k<3000;++k){for(int i=0;i<128;++i)l[i]=r[i]=.1f*std::sin((k*128+i)*.031);x->processReplacing(x,in,oa,128);y->processReplacing(y,in,ob,128);for(int i=0;i<128;++i)max=std::fmax(max,std::fabs(al[i]-bl[i]));}
 printf("mode %d max absolute difference from upstream core: %.9g\n",mode+1,max);assert(max<1.e-6);x->dispatcher(x,1,0,0,nullptr,0);y->dispatcher(y,1,0,0,nullptr,0);}
}
