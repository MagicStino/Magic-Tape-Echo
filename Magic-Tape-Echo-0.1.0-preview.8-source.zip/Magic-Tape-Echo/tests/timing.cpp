#include "../src/vst2.hpp"
#include "../src/timing.hpp"
#include <dlfcn.h>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstring>
static VstTimeInfo ti{};
static int updates=0;
static intptr_t host(AEffect*,int32_t op,int32_t,intptr_t,void*,float) {
 if(op==42)++updates;
 return op==7?reinterpret_cast<intptr_t>(&ti):0;
}
int main(int argc,char**argv) {
 assert(argc==2);auto lib=dlopen(argv[1],RTLD_NOW);assert(lib);
 auto make=(AEffect*(*)(audioMasterCallback))dlsym(lib,"VSTPluginMain");assert(make);
 for(double bpm:{20.,120.})for(int head:{0,1,2}) {
  auto* e=make(host);ti.tempo=bpm;ti.flags=1<<10;
  e->setParameter(e,25,1);e->setParameter(e,26,1);
  char text[32]{};e->dispatcher(e,7,25,0,text,0);assert(strstr(text,"48000.0 ms"));
  e->setParameter(e,16,1);e->setParameter(e,25,1);e->dispatcher(e,7,25,0,text,0);assert(!strcmp(text,"4 bars"));
  e->dispatcher(e,8,25,0,text,0);assert(!strcmp(text,"Time (note)"));
  e->setParameter(e,4,head/11.f);e->setParameter(e,3,1);e->setParameter(e,1,0);e->setParameter(e,11,0);
  e->dispatcher(e,10,0,0,nullptr,8000);assert(e->dispatcher(e,12,0,1,nullptr,0));
  float a[128]{},b[128]{},c[128]{},d[128]{};float*in[]={a,b};float*out[]={c,d};
  for(int n=0;n<32000;n+=128)e->processReplacing(e,in,out,128);
  updates=0;
  const int expected=int(16*60/bpm*8000);double early=0,arrival=0;
  for(int n=0;n<expected+1600;n+=128) {
   for(int i=0;i<128;++i)a[i]=b[i]=n+i<160 ? .4f*std::sin((n+i)*.4f):0;
   e->processReplacing(e,in,out,128);
   for(int i=0;i<128;++i){assert(std::isfinite(c[i]));double v=std::fabs(c[i]);if(n+i<expected-400)early=std::max(early,v);else arrival=std::max(arrival,v);}
  }
  printf("4 bars at %.0f BPM, head %d: expected %.1fs; early %.6f, arrival %.6f\n",bpm,head+1,expected/8000.,early,arrival);
  assert(arrival>.01 && early<arrival*.1);assert(updates==0);
  // Ordinary Time motion must not rebuild the host's automation page.
  for(int i=0;i<128;++i){e->setParameter(e,25,i/127.f);e->processReplacing(e,in,out,128);}assert(updates==0);
  // Sync swaps units once; redundant writes produce no further refresh.
  e->setParameter(e,16,0);for(int i=0;i<64;++i){e->setParameter(e,16,0);e->processReplacing(e,in,out,128);}assert(updates==1);
  e->dispatcher(e,7,25,0,text,0);assert(strstr(text,"ms"));
  e->dispatcher(e,1,0,0,nullptr,0);
 }
 for(int i=0;i<kTimeNotes;++i) {float n=float(i)/(kTimeNotes-1);assert(timeNoteIndex(n)==i);assert(std::fabs(noteTimeMs(n,120)-timeNotes[i].beats*500)<1e-8);}
 // Use actual host BPM to choose nearest duration; then reverse the switch.
 auto* e=make(host);ti.tempo=90;
 e->dispatcher(e,10,0,0,nullptr,8000);e->dispatcher(e,12,0,1,nullptr,0);
 float z[128]{},o[128]{},q[128]{};float*in[]={z,z};float*out[]={o,q};e->processReplacing(e,in,out,128);
 e->setParameter(e,25,timePositionForMs(330));e->setParameter(e,16,1);
 char label[32]{};e->dispatcher(e,7,25,0,label,0);assert(!strcmp(label,"1/8"));
 e->setParameter(e,16,0);assert(std::fabs(freeTimeMs(e->getParameter(e,25))-1000.0/3)<.001);
 // Save/reload and preset recall must not remap an already stored Time value.
 void* chunk=nullptr;auto bytes=e->dispatcher(e,23,0,0,&chunk,0);
 assert(e->dispatcher(e,24,0,bytes,chunk,0));assert(std::fabs(freeTimeMs(e->getParameter(e,25))-1000.0/3)<.001);
 for(int i=0;i<kTimeNotes;++i) {
   double ms=timeNotes[i].beats*60000/90;
   float nearest=nearestNotePosition(ms,90);
   assert(std::fabs(noteTimeMs(nearest,90)-ms)<1.e-7);
 }
 e->dispatcher(e,1,0,0,nullptr,0);
 dlclose(lib);puts("PASS: actual four-bar audio arrivals, all leading heads, 42 divisions, switchable units, selective refresh");
}
