#include "../src/vst2.hpp"
#include "../src/timing.hpp"
#include <cassert>
#include <dlfcn.h>
#include <cmath>
#include <cstdio>
static int vuReports=0,reelReports=0,allVisualReports=0;
static intptr_t host(AEffect*,int32_t op,int32_t idx,intptr_t,void*,float v){if(op==0&&(idx==20||idx==24||idx==27))++allVisualReports;if(op==0&&idx==20&&v>0)++vuReports;if(op==0&&idx==27)++reelReports;return 0;}
int main(int argc,char**argv){assert(argc==2);void*lib=dlopen(argv[1],RTLD_NOW);assert(lib);auto make=(AEffect*(*)(audioMasterCallback))dlsym(lib,"VSTPluginMain");assert(make);
 float l[128]{},r[128]{},a[128]{},b[128]{};float*in[]={l,r};float*out[]={a,b};
 auto*e=make(host);e->dispatcher(e,10,0,0,nullptr,44100);e->dispatcher(e,12,0,1,nullptr,0);
 e->setParameter(e,4,10/11.f);
 e->setParameter(e,5,.4f);e->setParameter(e,25,.5f);
 e->setParameter(e,4,0);assert(e->getParameter(e,28)==1&&e->getParameter(e,29)==0);
 e->setParameter(e,5,.8f);assert(e->getParameter(e,5)==.4f);
 e->setParameter(e,4,1);assert(e->getParameter(e,28)==0&&e->getParameter(e,29)==1);
 e->setParameter(e,25,.9f);assert(e->getParameter(e,25)==.5f);
 e->setParameter(e,5,.6f);assert(e->getParameter(e,5)==.6f);
 e->setParameter(e,4,10/11.f);e->setParameter(e,25,.7f);assert(e->getParameter(e,25)==.7f);
 e->setParameter(e,4,0);
 float previous=0;
 for(float amplitude:{.03f,.1f,.3f}){
  for(int k=0;k<1000;++k){for(int i=0;i<128;++i)l[i]=r[i]=amplitude*std::sin((k*128+i)*.1f);e->processReplacing(e,in,out,128);}
  float v=e->getParameter(e,20);printf("VU sine peak %.2f: needle %.3f\n",amplitude,v);assert(v>previous+.1f);previous=v;
 }
 assert(vuReports>20&&reelReports>20);
 for(int i=0;i<128;++i)l[i]=r[i]=0;
 for(int k=0;k<2000;++k)e->processReplacing(e,in,out,128);
 assert(e->getParameter(e,20)<.01f);
 e->setParameter(e,15,1);for(int k=0;k<100;++k)e->processReplacing(e,in,out,128);float reel=e->getParameter(e,27);for(int k=0;k<100;++k)e->processReplacing(e,in,out,128);assert(reel==e->getParameter(e,27));
 allVisualReports=0;for(int k=0;k<1000;++k)e->processReplacing(e,in,out,128);assert(allVisualReports==0);
 e->dispatcher(e,1,0,0,nullptr,0);
 for(int mode=0;mode<12;++mode){
  e=make(host);e->setParameter(e,4,mode/11.f);e->setParameter(e,25,timePositionForMs(100));e->setParameter(e,1,.90);e->setParameter(e,3,1);e->setParameter(e,5,.3);
  e->dispatcher(e,10,0,0,nullptr,8000);e->dispatcher(e,12,0,1,nullptr,0);double early=0,late=0;
  for(int n=0;n<64000;n+=128){for(int i=0;i<128;++i)l[i]=r[i]=n+i<160?.3f*std::sin((n+i)*.4f):0;e->processReplacing(e,in,out,128);for(int i=0;i<128;++i){assert(std::isfinite(a[i]));if(n<8000)early+=a[i]*a[i];if(n>=56000)late+=a[i]*a[i];}}
  printf("Head mode %d, feedback 90%%: tail/early %.6f\n",mode+1,late/early);assert(early>0&&late<early*.05);e->dispatcher(e,1,0,0,nullptr,0);
 }
 dlclose(lib);puts("PASS: VU movement/decay, meter notifications, reels, bypass stop, feedback decay across all head modes");}
