#include "../src/vst2.hpp"
#include <dlfcn.h>
#include <cassert>
#include <cmath>
#include <cstring>
#include <vector>
#include <chrono>
#include <cstdio>
#include <limits>
static VstTimeInfo ti{};
static int refreshes=0, feedback=0;
static intptr_t host(AEffect*,int32_t op,int32_t idx,intptr_t,void*,float) {if(op==42)++refreshes;if(op==0&&idx!=20&&idx!=24&&idx!=25&&idx!=27&&idx!=28&&idx!=29)++feedback;return op==7?reinterpret_cast<intptr_t>(&ti):op==1?2400:0;}
static void activate(AEffect* e,double sr) {e->dispatcher(e,10,0,0,nullptr,float(sr));e->dispatcher(e,12,0,1,nullptr,0);}
int main(int argc,char**argv) {
 assert(argc==2);void* lib=dlopen(argv[1],RTLD_NOW);if(!lib){puts(dlerror());return 1;}
 auto entry=reinterpret_cast<AEffect*(*)(audioMasterCallback)>(dlsym(lib,"VSTPluginMain"));assert(entry);
 AEffect* e=entry(host);AEffect* other=entry(host);assert(e&&other&&e!=other&&e->numInputs==2&&e->numParams==30&&e->numPrograms==20);
 for(int i=0;i<30;++i) {if(i==19||i==20||i==24||i>=27)continue;e->setParameter(e,4,10/11.f);assert(e->dispatcher(e,26,i,0,nullptr,0)==1);e->setParameter(e,i,1);assert(e->getParameter(e,i)==1);e->setParameter(e,i,std::numeric_limits<float>::quiet_NaN());assert(e->getParameter(e,i)==1);}
 assert(e->dispatcher(e,26,20,0,nullptr,0)==0);
 e->setParameter(e,19,1);assert(e->getParameter(e,19)==0);assert(e->dispatcher(e,26,19,0,nullptr,0)==0);
 // Repeated hardware deltas must accumulate across discrete option zones.
 for(int idx:{4,11,14,16,17,22,23,26}) {
  e->setParameter(e,4,10/11.f);
  e->setParameter(e,idx,0);
  for(int n=0;n<128;++n)e->setParameter(e,idx,e->getParameter(e,idx)+1.f/128);
  assert(e->getParameter(e,idx)==1);
  for(int n=0;n<128;++n)e->setParameter(e,idx,e->getParameter(e,idx)-1.f/128);
  assert(e->getParameter(e,idx)==0);
 }
 assert(feedback==0);
 assert(other->getParameter(other,0)!=e->getParameter(e,0));
 void* chunk=nullptr;auto bytes=e->dispatcher(e,23,0,0,&chunk,0);std::vector<char> saved((char*)chunk,(char*)chunk+bytes);
 e->setParameter(e,0,0);assert(e->dispatcher(e,24,0,bytes,saved.data(),0)==1);assert(e->getParameter(e,0)==1);
 assert(e->dispatcher(e,24,0,bytes-1,saved.data(),0)==0);
 e->dispatcher(e,1,0,0,nullptr,0);e=entry(host);
 float l[512]{},r[512]{},ol[512]{},orr[512]{};float* in[]={l,r};float* out[]={ol,orr};
 for(int p=0;p<20;++p) {
  assert(e->dispatcher(e,2,0,p,nullptr,0)==1);assert(e->dispatcher(e,3,0,0,nullptr,0)==p);
  char name[24]{};assert(e->dispatcher(e,29,p,0,name,0)==1);assert(name[0]);
  activate(e,44100);for(int i=0;i<512;++i)l[i]=r[i]=.1f*std::sin(i*.03f);
  for(int k=0;k<600;++k){e->processReplacing(e,in,out,128);for(int i=0;i<128;++i)assert(std::isfinite(ol[i])&&std::fabs(ol[i])<100);}
 }
 e->dispatcher(e,2,0,0,nullptr,0);
 ti.tempo=120;ti.flags=1<<10;
 for(double sr:{44100.,48000.,96000.}) {
  activate(e,sr);e->setParameter(e,15,1);
  for(int i=0;i<512;++i)l[i]=r[i]=float(std::sin(i*.03)*.1);
  for(int k=0;k<1000;++k)e->processReplacing(e,in,out,512);
  for(int i=0;i<512;++i)assert(std::fabs(ol[i]-l[i])<1.e-6&&std::fabs(orr[i]-r[i])<1.e-6);
  e->setParameter(e,15,0);e->setParameter(e,3,1); // wet only
  for(int mode=0;mode<12;++mode) {
   e->setParameter(e,4,mode/11.f);e->setParameter(e,5,.6f);e->setParameter(e,1,.95f);
   for(int n:{1,63,128,511}) {e->processReplacing(e,in,out,n);for(int i=0;i<n;++i)assert(std::isfinite(ol[i])&&std::fabs(ol[i])<100);}
  }
  e->dispatcher(e,12,0,0,nullptr,0);
 }
 e->dispatcher(e,1,0,0,nullptr,0);e=entry(host);activate(e,44100);
 for(int i=0;i<512;++i)l[i]=r[i]=float(std::sin(i*.13)*.1);
 for(int scenario=0;scenario<3;++scenario) {
  e->setParameter(e,4,scenario==1?10/11.f:0);e->setParameter(e,5,scenario==1?.5f:0);e->setParameter(e,15,scenario==2?1:0);
  for(int k=0;k<1000;++k)e->processReplacing(e,in,out,128);
  auto start=std::chrono::steady_clock::now();double peak=0;
  for(int k=0;k<10000;++k){auto b=std::chrono::steady_clock::now();e->processReplacing(e,in,out,128);double dt=std::chrono::duration<double>(std::chrono::steady_clock::now()-b).count();if(dt>peak)peak=dt;}
  double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
  printf("%s: %.3f%% of one core; worst block %.1f us (machine running this test)\n",scenario==0?"Tape":scenario==1?"Spring":"Bypass",seconds/(128.*10000/44100)*100,peak*1e6);
 }
 e->dispatcher(e,1,0,0,nullptr,0);other->dispatcher(other,1,0,0,nullptr,0);assert(feedback==0);dlclose(lib);puts("PASS: lifecycle, 24 automatable parameters and 20 presets, chunks, isolation, bypass, sample rates, modes, variable blocks");
}
