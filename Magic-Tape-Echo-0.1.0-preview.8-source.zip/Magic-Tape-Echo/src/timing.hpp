// Musical durations in quarter-note beats. Bars are 4/4.
#pragma once
#include <algorithm>
#include <cmath>
struct TimeNote {const char* label; double beats;};
static constexpr TimeNote timeNotes[] = {
{"1/128T", 0.0208333333333333},
{"1/128Q", 0.025},
{"1/128", 0.03125},
{"1/64T", 0.0416666666666667},
{"1/128D", 0.046875},
{"1/64Q", 0.05},
{"1/64", 0.0625},
{"1/32T", 0.0833333333333333},
{"1/64D", 0.09375},
{"1/32Q", 0.1},
{"1/32", 0.125},
{"1/16T", 0.166666666666667},
{"1/32D", 0.1875},
{"1/16Q", 0.2},
{"1/16", 0.25},
{"1/8T", 0.333333333333333},
{"1/16D", 0.375},
{"1/8Q", 0.4},
{"1/8", 0.5},
{"1/4T", 0.666666666666667},
{"1/8D", 0.75},
{"1/4Q", 0.8},
{"1/4", 1},
{"1/2T", 1.33333333333333},
{"1/4D", 1.5},
{"1/2Q", 1.6},
{"1/2", 2},
{"1/1T", 2.66666666666667},
{"1/2D", 3},
{"1/1Q", 3.2},
{"1/1", 4},
{"2 barsT", 5.33333333333333},
{"1/1D", 6},
{"2 barsQ", 6.4},
{"2 bars", 8},
{"3 barsT", 8},
{"3 barsQ", 9.6},
{"4 barsT", 10.6666666666667},
{"2 barsD", 12},
{"3 bars", 12},
{"4 barsQ", 12.8},
{"4 bars", 16},
};
static constexpr int kTimeNotes=sizeof(timeNotes)/sizeof(timeNotes[0]);
inline int timeNoteIndex(float n) {return std::clamp(int(std::lround(n*(kTimeNotes-1))),0,kTimeNotes-1);}
inline double freeTimeMs(float n) {return std::exp(double(n)*std::log(48000.0));}
inline double noteTimeMs(float n,double bpm) {return timeNotes[timeNoteIndex(n)].beats*60000.0/bpm;}

inline float timePositionForMs(double ms) {
    return float(std::log(std::clamp(ms,1.0,48000.0))/std::log(48000.0));
}
inline float nearestNotePosition(double ms,double bpm) {
    int best=0; double error=1.e30;
    for(int i=0;i<kTimeNotes;++i) {
        const double delta=std::fabs(timeNotes[i].beats*60000.0/bpm-ms);
        if(delta<error) {best=i;error=delta;}
    }
    return float(best)/(kTimeNotes-1);
}

// Fine control over decaying repeats; self-oscillation occupies the top end.
inline float feedbackCurve(float n) {
    if(n<=.92f)return n*(.60f/.92f);
    if(n<=.98f)return .60f+(n-.92f)*(.15f/.06f);
    return .75f+(n-.98f)*(.25f/.02f);
}
