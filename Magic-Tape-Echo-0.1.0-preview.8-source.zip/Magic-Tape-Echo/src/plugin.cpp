// Magic Tape Echo: floating-point native VST2 effect. GPL-3.0-or-later.
#include "vst2.hpp"
#include "parameters.hpp"
#include "presets.hpp"
#include "timing.hpp"
#include "dsp/core/TapeEchoDSP.hpp"
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <new>

static_assert(std::atomic<float>::is_always_lock_free, "Audio controls require lock-free floats");
struct State {
    AEffect fx{};
    audioMasterCallback host{};
    duskaudio::TapeEchoDSP dsp;
    std::atomic<float> values[kCount];
    double sr=44100;
    std::atomic<float> tempo{120};
    bool ready=false;
    std::atomic<float> vu{0}, peak{0}, reels{0};
    double reelPhase=0;
    std::atomic<bool> timeLabelDirty{false}, timeValueDirty{false}, sectionDirty{false};
    int displayWait=0;
    float slowVu=0;
    float vuAttack[129]{},vuRelease[129]{};
    int reportedVu=-1,reportedPeak=-1,reportedReel=-1;
    int vuFrames=0;
    struct Chunk { uint32_t magic=0x4d675445, version=1, count=kCount; float values[kCount]{}; } chunk;
    State() { for(int i=0;i<kCount;++i) values[i].store((parameters[i].def-parameters[i].lo)/(parameters[i].hi-parameters[i].lo)); }
    float n(int i) const {return values[i].load(std::memory_order_relaxed);}
    float real(int i) const {auto &p=parameters[i]; float v=p.lo+n(i)*(p.hi-p.lo); return p.steps ? std::round(v):v;}
    bool echoActive() const {return int(real(4))!=11;}
    bool reverbActive() const {return int(real(4))>=4;}
    bool enabled(int i) const {
        switch(i) {
        case 1:case 2:case 8:case 9:case 10:case 11:case 12:case 14:case 16:case 18:case 25:return echoActive();
        case 5:case 13:return reverbActive();
        default:return true;
        }
    }
    void migrateTiming() {
        if(n(26)>.5f)return;
        const int mode=1+int(real(4));
        float rate=n(0);
        if(n(16)>.5f) {
            const int division=n(23)>.5f ? teDivisionForSyncKnobPos(int(real(22))-1,teLeadingHeadIndexForMode(mode)) : int(real(17));
            rate=dsp.repeatRateForDelayMs(float((syncDelayMs(tempo.load(),division)-dsp.leadingHeadOffsetMsForMode(mode))/dsp.leadingHeadRatioForMode(mode)));
        }
        const double ms=dsp.delayMsForRepeatRate(rate)*dsp.leadingHeadRatioForMode(mode)+dsp.leadingHeadOffsetMsForMode(mode);
        values[25].store(n(16)>.5f?nearestNotePosition(ms,tempo.load()):timePositionForMs(ms));
        values[26].store(1);
    }
    void apply() {
        dsp.setMode(1+int(real(4))); dsp.setIntensity(feedbackCurve(n(1))); dsp.setEchoLevel(n(2)); dsp.setMix(n(3));
        dsp.setReverbLevel(n(5)); dsp.setInputGain(n(6)); dsp.setOutputVolume(n(7));
        dsp.setBass(real(8)); dsp.setTreble(real(9)); dsp.setWowFlutter(n(10)); dsp.setTapeAge(n(11));
        dsp.setEchoPan(n(12)); dsp.setReverbPan(n(13)); dsp.setInputSend(n(14)>.5f); dsp.setBypass(n(15)>.5f);
        dsp.setDryLevel(n(21));
        dsp.setNoise(n(18));
        const int mode=1+int(real(4));
        const double leadingMs=n(16)>.5f ? noteTimeMs(n(25),tempo.load(std::memory_order_relaxed)) : freeTimeMs(n(25));
        const float overrideMs=float((leadingMs-dsp.leadingHeadOffsetMsForMode(mode))/dsp.leadingHeadRatioForMode(mode));
        const float rate=dsp.repeatRateForDelayMs(overrideMs);
        dsp.setDelayOverrideMs(overrideMs);
        dsp.setRepeatRate(rate);
    }
};
static State* state(AEffect* e) { return static_cast<State*>(e->object); }
static void set(AEffect* e,int32_t i,float v) {
    if(i<0 || i>=kCount || !isControl(i) || !std::isfinite(v)) return;
    v=std::clamp(v,0.f,1.f);
    // Preserve the host's continuous position, quantize only at real()/DSP use.
    // Quantizing readback here loses repeated 1/128 Q-Link increments on short
    // option lists (the next increment is always measured from the same value).
    // Never call UpdateDisplay for a host write: MPC rebuilds its automation
    // page and can snap Q-Links back (mpc-vst-plugins discussion #499).
    auto* s=state(e);
    if(!s->enabled(i))return;
    const float old=s->values[i].exchange(v,std::memory_order_relaxed);
    if(i==4 && std::lround(old*11)!=std::lround(v*11)) {
        s->sectionDirty.store(true,std::memory_order_relaxed);
        s->timeLabelDirty.store(true,std::memory_order_relaxed);
    }
    // Only a Sync state transition changes another control's units/name.
    // Defer and coalesce this exceptional refresh; Time/Q-Link moves do not.
    if(i==16 && (old>.5f)!=(v>.5f)) {
        const double bpm=s->tempo.load(std::memory_order_relaxed);
        const float previous=s->n(25);
        const float mapped=v>.5f ? nearestNotePosition(freeTimeMs(previous),bpm)
                                 : timePositionForMs(noteTimeMs(previous,bpm));
        s->values[25].store(mapped,std::memory_order_relaxed);
        s->timeValueDirty.store(true,std::memory_order_relaxed);
        s->timeLabelDirty.store(true,std::memory_order_relaxed);
    }
}
static float get(AEffect* e,int32_t i) { return i==28 ? float(state(e)->echoActive()) : i==29 ? float(state(e)->reverbActive()) : i==27 ? state(e)->reels.load(std::memory_order_relaxed) : i==20 ? state(e)->vu.load(std::memory_order_relaxed) : i==24 ? state(e)->peak.load(std::memory_order_relaxed) : i>=0 && i<kCount ? state(e)->n(i):0; }
static void copy(void* p,const char* text,int size) { if(p) std::snprintf(static_cast<char*>(p),size,"%s",text); }
static void process(AEffect* e,float** in,float** out,int32_t count) {
    if(count<=0 || !in || !out || !in[0] || !in[1] || !out[0] || !out[1]) return;
    auto* s=state(e);
    if(!s->ready) { for(int c=0;c<2;++c) std::memmove(out[c],in[c],size_t(count)*sizeof(float)); return; }
    if(s->host) {
        auto* t=reinterpret_cast<VstTimeInfo*>(s->host(e,7,0,1<<10,nullptr,0));
        if(t && (t->flags&(1<<10)) && std::isfinite(t->tempo) && t->tempo>=20 && t->tempo<=999) s->tempo=t->tempo;
    }
    s->apply();
    if(s->sectionDirty.exchange(false,std::memory_order_relaxed) && s->host) {
        s->host(e,0,28,0,nullptr,float(s->echoActive()));
        s->host(e,0,29,0,nullptr,float(s->reverbActive()));
    }
    if(s->timeValueDirty.exchange(false,std::memory_order_relaxed) && s->host)
        s->host(e,0,25,0,nullptr,s->n(25));
    s->displayWait=std::max(0,s->displayWait-count);
    if(s->displayWait==0 && s->timeLabelDirty.exchange(false,std::memory_order_relaxed)) {
        if(s->host) s->host(e,42,0,0,nullptr,0);
        s->displayWait=int(s->sr*.05);
    }
    // No allocations, locks, integer conversion, or device I/O in this path.
    // Subdivide oversized host buffers to keep control refresh cost predictable.
    for(int pos=0;pos<count;pos+=128) {
        const float* input[2]={in[0]+pos,in[1]+pos}; float* output[2]={out[0]+pos,out[1]+pos};
        const int frames=std::min(128,count-pos);
        s->dsp.processBlock(input,output,2,frames);
        // Additional gentle ballistics on the upstream 225/200ms record meter.
        float target=s->dsp.getRecordVuLevel();
        const float coeff=target>s->slowVu?s->vuAttack[frames]:s->vuRelease[frames];
        s->slowVu += coeff*(target-s->slowVu);
        s->vuFrames+=frames;
        if(s->vuFrames>=int(s->sr/20)) {
            s->vuFrames%=int(s->sr/20);
            // The native skin can only display 65 distinct needle frames.
            // Convert to dB at display rate, not once per audio sub-block.
            const int vuFrame=int(std::lround(std::clamp((20.f*std::log10(std::max(s->slowVu,1.e-6f))+38.f)/23.f,0.f,1.f)*64));
            const float needle=vuFrame/64.f;
            s->vu.store(needle,std::memory_order_relaxed);
            if(s->n(15)<.5f) {s->reelPhase+=.05*.6;s->reelPhase-=std::floor(s->reelPhase);}
            s->reels.store(float(int(s->reelPhase*12))/11.f,std::memory_order_relaxed);
            s->peak.store(s->dsp.getRecordPeakLevel()>=.89125f?1.f:0.f,std::memory_order_relaxed);
            const int reelFrame=int(std::lround(s->reels.load(std::memory_order_relaxed)*11));
            const int peakFrame=int(s->peak.load(std::memory_order_relaxed));
            if(s->host) {
                if(reelFrame!=s->reportedReel) s->host(e,0,27,0,nullptr,reelFrame/11.f);
                if(vuFrame!=s->reportedVu) s->host(e,0,20,0,nullptr,needle);
                if(peakFrame!=s->reportedPeak) s->host(e,0,24,0,nullptr,float(peakFrame));
            }
            s->reportedReel=reelFrame;s->reportedVu=vuFrame;s->reportedPeak=peakFrame;
        }
    }
}
static int program(State* s) {
    for(int p=0;p<kPrograms;++p) {
        bool match=true;
        for(int i=0;i<kCount;++i) if(isControl(i) && std::fabs(s->n(i)-presets[p].values[i])>1.e-6f) {match=false;break;}
        if(match)return p;
    }
    return -1;
}
static intptr_t dispatch(AEffect* e,int32_t op,int32_t idx,intptr_t value,void* ptr,float opt) {
    auto* s=state(e);
    switch(op) {
    case 0: return 1;
    case 1: delete s; return 1;
    case 2:
        if(value<0 || value>=kPrograms)return 0;
        for(int i=0;i<kCount;++i) if(isControl(i)) s->values[i].store(presets[value].values[i],std::memory_order_relaxed);
        s->timeValueDirty.store(false,std::memory_order_relaxed);
        s->sectionDirty.store(true,std::memory_order_relaxed);
        s->timeLabelDirty.store(true,std::memory_order_relaxed);
        return 1;
    case 3: return std::max(0,program(s));
    case 5: {int p=program(s);copy(ptr,p<0?"Edited":presets[p].name,24);return 1;}
    case 6: copy(ptr,"",8); return 1;
    case 7:
        if(idx>=0 && idx<kCount && isMeter(idx)) {copy(ptr,"VU",24);return 1;}
        if(idx<0 || idx>=kCount || !ptr) return 0;
        if(idx==25) {
            if(s->n(16)>.5f) copy(ptr,timeNotes[timeNoteIndex(s->n(25))].label,24);
            else std::snprintf(static_cast<char*>(ptr),24,"%.1f ms",freeTimeMs(s->n(25)));
        }
        else if(idx==22) std::snprintf(static_cast<char*>(ptr),24,"%d",int(s->real(idx)));
        else if(parameters[idx].labels[0]) copy(ptr,parameters[idx].labels[int(s->real(idx)+.5f)],24);
        else std::snprintf(static_cast<char*>(ptr),24,"%.1f",s->real(idx)*100);
        return 1;
    case 8: if(idx==25) {copy(ptr,s->n(16)>.5f ? "Time (note)" : "Time (ms)",32);return 1;} if(idx>=0 && idx<kCount && isMeter(idx)) {copy(ptr,parameters[idx].name,32);return 1;} if(idx<0 || idx>=kCount) return 0; copy(ptr,parameters[idx].name,32); return 1;
    case 10: if(std::isfinite(opt) && opt>=8000 && opt<=192000) s->sr=opt; return 1;
    case 11: return 1;
    case 12:
        if(value) { try { s->apply(); s->dsp.prepare(s->sr,128);
            for(int f=0;f<=128;++f) {s->vuAttack[f]=1.f-std::exp(-f/float(s->sr*.15));s->vuRelease[f]=1.f-std::exp(-f/float(s->sr*.45));}
            s->reportedVu=s->reportedPeak=s->reportedReel=-1;
            s->ready=true; } catch(...) {s->ready=false;return 0;} }
        else s->ready=false;
        return 1;
    case 23:
        if(!ptr) return 0;
        for(int i=0;i<kCount;++i) s->chunk.values[i]=isControl(i)?s->n(i):0;
        *static_cast<void**>(ptr)=&s->chunk; return sizeof(s->chunk);
    case 24: {
        if(!ptr || value<12) return 0;
        uint32_t h[3]; std::memcpy(h,ptr,12);
        if(h[0]!=0x4d675445 || h[1]!=1 || h[2]>kCount || value!=intptr_t(12+4*h[2])) return 0;
        float vals[kCount];
        std::memcpy(vals,static_cast<char*>(ptr)+12,4*h[2]);
        for(unsigned i=0;i<h[2];++i) if(!std::isfinite(vals[i]) || vals[i]<0 || vals[i]>1) return 0;
        for(int i=0;i<kCount;++i) if(isControl(i)) s->values[i].store(i<int(h[2])?vals[i]:(parameters[i].def-parameters[i].lo)/(parameters[i].hi-parameters[i].lo),std::memory_order_relaxed);
        s->migrateTiming();
        s->timeValueDirty.store(false,std::memory_order_relaxed);
        s->sectionDirty.store(true,std::memory_order_relaxed);
        s->timeLabelDirty.store(true,std::memory_order_relaxed);
        return 1;
    }
    case 26: return idx>=0 && idx<kCount && isControl(idx);
    case 29: if(idx<0 || idx>=kPrograms) return 0; copy(ptr,presets[idx].name,24);return 1;
    case 35: return 1;
    case 44: set(e,15,value?1.f:0.f);return 1;
    case 45: case 48: copy(ptr,"Magic Tape Echo",32);return 1;
    case 47: copy(ptr,"MagicStino",32);return 1;
    case 49: return 100;
    case 51: return ptr && std::strcmp(static_cast<char*>(ptr),"receiveVstTimeInfo")==0 ? 1:0;
    case 52: return 0; // unknown/unbounded tail under self-oscillation
    case 58: return 2400;
    default:return 0;
    }
}
extern "C" __attribute__((visibility("default"))) AEffect* VSTPluginMain(audioMasterCallback host) {
    auto* s=new(std::nothrow) State; if(!s) return nullptr;
    s->host=host; auto& e=s->fx; e.magic=0x56737450;e.dispatcher=dispatch;e.setParameter=set;e.getParameter=get;
    e.numPrograms=kPrograms;e.numParams=kCount;e.numInputs=2;e.numOutputs=2;e.flags=(1<<4)|(1<<5);
    e.object=s;e.uniqueID=0x4d675445;e.version=100;e.processReplacing=process;e.ioRatio=1;
    return &e;
}
