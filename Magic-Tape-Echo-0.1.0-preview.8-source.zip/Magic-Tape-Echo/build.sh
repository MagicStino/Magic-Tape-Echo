#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 tools/parameters.py
mkdir -p build
CXX="${CXX:-g++}"
TARGET="${1:-host}"
OUT=build/host
FLAGS=()
if [ "$TARGET" = armv7 ]; then
 OUT=build/armv7
 CXX="${CXX_ARM:-arm-linux-gnueabihf-g++}"
 FLAGS=(-mcpu=cortex-a17 -mfpu=neon-vfpv4 -mfloat-abi=hard -static-libstdc++ -static-libgcc)
elif [ "$TARGET" != host ]; then
 echo 'Usage: ./build.sh [host|armv7]' >&2; exit 2
fi
mkdir -p "$OUT"
"$CXX" -std=c++17 -O3 -Wall -Wextra -fPIC -shared -fvisibility=hidden "${FLAGS[@]}" -Isrc/dsp/shared src/plugin.cpp src/dsp/core/TapeEchoDSP.cpp -Wl,--no-undefined -o "$OUT/magic_tape_echo.so"
if [ "$TARGET" = host ]; then
 "$CXX" -std=c++17 -O2 tests/host.cpp -ldl -o build/host-test
 ./build/host-test "$PWD/$OUT/magic_tape_echo.so"
 "$CXX" -std=c++17 -O2 tests/timing.cpp -ldl -o build/timing-test
 ./build/timing-test "$PWD/$OUT/magic_tape_echo.so"
 "$CXX" -std=c++17 -O2 tests/panel.cpp -ldl -o build/panel-test
 ./build/panel-test "$PWD/$OUT/magic_tape_echo.so"
fi
