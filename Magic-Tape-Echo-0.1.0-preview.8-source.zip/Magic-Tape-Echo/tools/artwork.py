from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
import math,json
r=Path(__file__).resolve().parents[1]; a=r/'vst/art';a.mkdir(exist_ok=True)
def font(size,bold=False):return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans'+('-Bold' if bold else '')+'.ttf',size)
def text(d,xy,s,size,color,bold=False,anchor=None):d.text(xy,s,font=font(size,bold),fill=color,anchor=anchor)
S=2
for page,subtitle in [('echo','THREE HEADS / MAGNETIC DELAY'),('character','TAPE CHARACTER / SIGNAL ROUTING')]:
 im=Image.new('RGB',(1280,628),'#e4dcc6');d=ImageDraw.Draw(im)
 for y in range(628):
  v=int(228-12*y/628);d.line((0,y,1280,y),fill=(v,v-8,v-29))
 d.rounded_rectangle((14,14,1265,613),radius=17,outline='#958c75',width=2)
 d.rounded_rectangle((30,30,1250,190),radius=12,fill='#203b36')
 text(d,(58,48),'M A G I C',22,'#dab879',True)
 text(d,(56,79),'TAPE ECHO',48,'#f5e8cc',True)
 text(d,(59,145),subtitle,14,'#b9cbb4')
 text(d,(495,72),'SYNC',12,'#e5d7b8',True,'mm')
 text(d,(585,72),'FEED INPUT',12,'#e5d7b8',True,'mm')
 text(d,(1215,157),'PEAK',10,'#e5d7b8',True,'mm')
 d.line((60,210,1220,210),fill='#b8ad92',width=1)
 text(d,(60,594),'MAGICSTINO',12,'#54695a',True)
 text(d,(1220,594),'TAPE ECHO 2 ENGINE  /  DUSK AUDIO',11,'#6c7162',anchor='ra')
 for x,y in [(28,28),(1252,28),(28,600),(1252,600)]:
  d.ellipse((x-5,y-5,x+5,y+5),fill='#b7af9c',outline='#7d796d');d.line((x-3,y+2,x+3,y-2),fill='#686458',width=1)
 # Static color rings share one knob strip, saving device texture memory.
 if page=='echo':
  d.arc((423,217,547,341),135,405,fill='#b45f38',width=4)
  d.arc((423,217,547,341),383,405,fill='#b93d2a',width=5)
  d.arc((423,407,547,531),135,405,fill='#4b93bd',width=4)
 else:d.arc((1033,407,1157,531),135,405,fill='#4b93bd',width=4)
 im.save(a/f'{page}.png')
# Hand-drawn hardware knob, 128 frames, 124px tall = 15872px under the device limit.
w=124;strip=Image.new('RGBA',(w,w*128))
for f in range(128):
 im=Image.new('RGBA',(w*2,w*2));d=ImageDraw.Draw(im);cx=cy=w
 d.ellipse((20,25,228,233),fill='#a59b83')
 d.ellipse((18,18,230,230),fill='#172b26',outline='#68796a',width=3)
 for k in range(48):
  t=k*math.pi/24;d.line((cx+94*math.cos(t),cy+94*math.sin(t),cx+102*math.cos(t),cy+102*math.sin(t)),fill='#758071',width=2)
 d.ellipse((34,34,214,214),fill='#2a4036',outline='#8f9883',width=3)
 d.ellipse((44,44,204,204),fill='#23362f',outline='#1c2c25',width=2)
 t=math.radians(135+270*f/127);d.line((cx+37*math.cos(t),cy+37*math.sin(t),cx+83*math.cos(t),cy+83*math.sin(t)),fill='#f0d4a0',width=8)
 im=im.resize((w,w),Image.Resampling.LANCZOS);strip.paste(im,(0,f*w))
strip.save(a/'knob.png')
# 65 compact VU frames, native filmstrip rendering. 160*65=10400px.
w,h=340,150;strip=Image.new('RGB',(w,h*65))
for f in range(65):
 im=Image.new('RGB',(w*2,h*2),'#203b36');d=ImageDraw.Draw(im)
 d.rounded_rectangle((4,4,676,296),radius=20,fill='#152721',outline='#77816b',width=3)
 d.rounded_rectangle((20,18,660,278),radius=14,fill='#eddfb9',outline='#aa916a',width=3)
 cx,cy=340,275
 for k in range(41):
  ang=math.radians(215+110*k/40);rad=205
  x=cx+rad*math.cos(ang);y=cy+rad*math.sin(ang)
  x2=cx+(rad-14 if k%5 else rad-23)*math.cos(ang);y2=cy+(rad-14 if k%5 else rad-23)*math.sin(ang)
  d.line((x,y,x2,y2),fill='#a95032' if k>34 else '#34433b',width=3)
 for frac,label in [(0,'-20'),(10/23,'-10'),(15/23,'-5'),(20/23,'0'),(1,'+3')]:
  t=math.radians(215+110*frac);text(d,(cx+235*math.cos(t),cy+235*math.sin(t)),label,19,'#475042',True,'mm')
 text(d,(340,165),'VU',28,'#34483b',True,'mm');text(d,(340,203),'0 VU = -18 dBFS',13,'#72745b',False,'mm')
 t=math.radians(215+110*f/64);d.line((cx+3,cy+3,cx+191*math.cos(t)+3,cy+191*math.sin(t)+3),fill='#b6a887',width=5)
 d.line((cx,cy,cx+191*math.cos(t),cy+191*math.sin(t)),fill='#8b3d25',width=4)
 d.ellipse((cx-15,cy-15,cx+15,cy+15),fill='#293d31')
 strip.paste(im.resize((w,h),Image.Resampling.LANCZOS),(0,f*h))
strip.save(a/'vu.png')

# Animated reels are a tiny 12-frame strip; no browser or animation thread.
strip=Image.new('RGB',(180,1200),'#203b36')
for f in range(12):
 im=Image.new('RGB',(180,100),'#203b36');d=ImageDraw.Draw(im)
 for x,col in [(40,'#d9aa50'),(140,'#bd705b')]:
  d.ellipse((x-29,10,x+29,68),fill='#394c40',outline=col,width=3)
  for k in range(3):
   t=math.radians(k*120+f*10);u=x+17*math.cos(t);v=39+17*math.sin(t)
   d.ellipse((u-6,v-6,u+6,v+6),fill=col)
  d.ellipse((x-4,35,x+4,43),fill='#efe1ba')
 d.line((40,69,60,85,120,85,140,69),fill='#d8b56c',width=2)
 strip.paste(im,(0,f*100))
strip.save(a/'reels.png')
colors=['#d9aa50','#db785a','#6cb89a','#68a6d0']
active=[(0,),(1,),(2,),(1,2),(0,3),(1,3),(2,3),(0,1,3),(1,2,3),(0,2,3),(0,1,2,3),(3,)]
strip=Image.new('RGB',(245,26*12),'#203b36')
for f,ids in enumerate(active):
 im=Image.new('RGB',(245,26),'#203b36');d=ImageDraw.Draw(im)
 for i,label in enumerate(['H1','H2','H3','SPRING']):
  x=i*55+7;col=colors[i] if i in ids else '#536356'
  d.ellipse((x,9,x+6,15),fill=col);text(d,(x+10,12),label,11,col,True,'lm')
 strip.paste(im,(0,f*26))
strip.save(a/'heads.png')

# Inactive sections remain visible but carry no touch actions.
from PIL import ImageEnhance
src=Image.open(a/'knob.png').convert('RGBA').crop((0,40*124,124,42*124));gray=ImageEnhance.Color(src).enhance(0)
wash=Image.new('RGBA',src.size,'#d9d4c1');gray=Image.blend(gray,wash,.55);gray.putalpha(src.getchannel('A'));gray.save(a/'disabled-knob.png')
sw=Image.new('RGBA',(40,128))
for f in range(2):
 im=Image.new('RGBA',(40,64));d=ImageDraw.Draw(im)
 d.ellipse((3,15,37,49),fill='#bcbdb3',outline='#a8aa9e',width=2)
 d.line((20,32,20,55),fill='#a0a399',width=5);d.ellipse((14,49,26,61),fill='#c9cbbf')
 sw.paste(im,(0,f*64))
sw.save(a/'disabled-switch.png')

# Passive status LEDs: reuse the switch parameter, no extra DSP/UI polling.
led=Image.new('RGB',(16,32),'#203b36')
for state in range(2):
 im=Image.new('RGB',(64,64),'#203b36');d=ImageDraw.Draw(im)
 d.ellipse((3,3,61,61),fill='#132720',outline='#788577',width=3)
 d.ellipse((11,11,53,53),fill='#79e687' if state else '#344c3d')
 if state:d.ellipse((17,15,31,27),fill='#e7ffd6')
 led.paste(im.resize((16,16),Image.Resampling.LANCZOS),(0,state*16))
led.save(a/'switch-led.png')
