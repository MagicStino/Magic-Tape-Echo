#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${MPC_VST:?Set MPC_VST to mpc-vst-plugins checkout at 97a2effca4114dd00f738b018e2f0d1d3ccb2d7f}"
# Python 3 with Pillow + Playwright Chromium installed is needed for build-time artwork only.
python3 "$MPC_VST/tools/gen_vst.py" vst/vst.json
python3 "$MPC_VST/tools/studio.py" preview "vst/build/skin/MagicStino - VST - Magic Tape Echo/Plugin Skins" -o 'docs/panel-%d.png'
