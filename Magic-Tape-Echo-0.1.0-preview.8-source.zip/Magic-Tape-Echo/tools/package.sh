#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${MPC_VST:?Set MPC_VST to the pinned mpc-vst-plugins checkout}"
python3 "$MPC_VST/tools/release.py" --so build/armv7/magic_tape_echo.so --skin 'vst/build/skin/MagicStino - VST - Magic Tape Echo' --entry vst/build/pluginlist-entry.xml --version 0.1.0-preview.8 --id magic-tape-echo --repo MagicStino/Magic-Tape-Echo --license GPL-3.0-or-later --about 'Three-head tape echo with optional spring reverb and a slow needle VU. Extended timing and nearest-note conversion tested locally; latest hardware validation pending.' -o dist
