# Q-Links, macros and automation research

Research and implementation: 22 October 2026. Sources distinguish documented host features from evidence for this particular plugin.

## Source evidence

- Akai's [Force User Guide v3.7](https://cdn.inmusicbrands.com/Software/37/Force%20-%20User%20Guide%20-%20v3.7.pdf), printed pp. 279–292: Q-Link Edit, learning assignments, parameter ranges, XY, crossfader, pad grid and envelope/LFO macros. Page 280 describes Learn/Add/Range; p. 281 explicitly lists audio-track Insert 1–4 parameters; p. 287 limits Track FX Rack assignments to the selected track's inserts and allows saving in an FX Rack preset. The Automation section describes Off/Read/Write, with Write overwriting existing data.
- Akai [MIDI Learn troubleshooting](https://support.akaipro.com/en/support/solutions/articles/69000876478-akai-pro-mpc-series-troubleshooting-midi-learn-mappings): controller routing and MIDI Learn are distinct from an internal macro assignment. A learned CC-to-macro message alone does not establish the intended parameter mapping.
- [MPC native plugin porting guide](https://github.com/sd88me/mpc-vst-plugins/blob/97a2effca4114dd00f738b018e2f0d1d3ccb2d7f/docs/PORTING.md) and [reverse-engineering notes](https://github.com/sd88me/mpc-vst-plugins/blob/97a2effca4114dd00f738b018e2f0d1d3ccb2d7f/docs/NOTES.md): stable VST indices; native Parameter N skin handles; hardware Q-Link bank ordering; effects vs instruments; previous on-device stepping measurements; image height limits; filmstrip meters rather than the unreliable native Meter component.

## Parameter contract

| Index | Parameter | Page |
|---:|---|---|
| 0 | Legacy Repeat Rate | Compatibility only |
| 1 | Intensity | Echo |
| 2 | Echo Level | Echo |
| 3 | Mix | Echo |
| 4 | Head Mode | Echo |
| 5 | Spring Level | Echo |
| 6 | Input Drive | Echo |
| 7 | Output | Echo |
| 8 | Bass | Character |
| 9 | Treble | Character |
| 10 | Wow Flutter | Character |
| 11 | Tape Age | Character |
| 12 | Echo Pan | Character |
| 13 | Spring Pan | Character |
| 14 | Tape Send | Character |
| 15 | Bypass | Character |
| 16 | Sync | Echo metal switch |
| 17 | Legacy Sync Note | Compatibility only |
| 18 | Tape Hiss | Character |
| 19 | Unused compatibility slot | Hidden; not automatable |
| 20 | Record VU | All pages; display only |
| 21 | Dry Signal | Character |
| 22 | Legacy Rate Note | Compatibility only |
| 23 | Legacy Sync Mapping | Compatibility only |
| 24 | Record Peak | All pages; display only |
| 25 | Time (ms / note) | Echo |
| 26 | Legacy Timing Range | Compatibility only |
| 27 | Tape Motion | Display only |

All indices except 19, 20 and 24 return true for VST effCanBeAutomated. Values are normalized, clamped, atomically stored, and read by the DSP on its next host block. The same parameters drive the touchscreen, Q-Link map, host automation and saved-state chunk; no separate UI-only controls. Options retain continuous host positions for Q-Link delta accumulation and quantize only in the DSP, rather than using relative nudge heuristics, so automation playback cannot be misinterpreted as a wheel movement. Hardware turning speed of short option lists still needs testing.

The skin generator maps the listed page controls into the host Q-Link grid. **Do not equate list order with physical knob numbers**: Force's Column bank setting and the MPC's four-knob banks differ. The generated `Q-Links.json` is authoritative; confirm physical order on your model. Meter indices 20 and 24 are omitted from all Q-Link banks, ignores setParameter, and have reserved zero state slots and no automation availability. It publishes visual updates at 20 Hz using the host notification route used by community meter ports. Confirm that your firmware does not create a meter automation lane during Write.

## Force assignment workflow

1. Insert Magic Tape Echo on the intended track. Hold Knobs and choose Screen to use the page controls directly.
2. Open Q-Link Edit/Macros; choose an editable Project or Track mode and select the intended macro. Tap Learn, visit this effect page, move a parameter, return and turn Learn off.
3. The `+` picker is an alternative: select the track, Insert slot, then the named parameter. This is useful if touch learning does not capture a particular firmware's custom-plugin gesture.
4. Use Add for multiple parameters and Range to constrain their travel. The Track FX Rack mode is limited to inserts on that track; Project mode is the documented route for wider assignments. Save the FX Rack/project as appropriate.
5. Put track/global automation in Write, record a short move, stop, return to Read, replay and inspect the lane. Save/reload the project and replay again. Test clip and arranger workflows separately.

Suggested mappings (manual recipes, not claimed pre-installed project macros):
- **Dub throw**: Tape Send Off/On with a pad or momentary macro. This cuts new tape input while echoes continue; spring has its own input path.
- **Feedback ride**: Intensity range 30–70% for ordinary performance; extend deliberately for self-oscillation.
- **Tape wear**: Wow Flutter plus Treble reduction. Tape Age is discrete; it will step.
- **Wet crossfade**: Mix, or Echo Level and Spring Level with constrained ranges. Aux/send use normally keeps Mix at 100%.
- **LFO movement**: slow host LFO on Repeat Rate for pitch bends; keep Tempo Sync off, because sync otherwise owns the motor.

Host XY, pad-grid, crossfader and envelope/LFO assignments are documented Force capabilities, but their operation with this new plugin remains an interactive hardware test until recorded below. MPC firmware/model availability differs; a Force result is not automatically an MPC result.

## Sync and MIDI distinctions

Extended timing uses host BPM and the same Time control for milliseconds or notes. Sync on snaps the previous milliseconds to the nearest of 42 straight, dotted, triplet or quintuplet durations; Sync off converts the selected duration back to milliseconds. Ties choose the first equal/nearest duration in the table. Bars mean 4/4. Four bars is 8 seconds at 120 BPM or 48 seconds at 20 BPM. The leading head is synchronized; subsequent heads retain their spacing. Original timing separately retains the upstream motor-limited legacy notes/detents. Missing tempo uses the last valid value, initially 120 BPM. Preset/chunk restoration bypasses toggle conversion. Automating Sync converts Time once per transition, so record both lanes when performing mode changes; actual Force recording/playback remains to be checked.

This custom wrapper deliberately does not advertise MIDI input or hard-wire CC20–35/NRPN. MIDI arriving at an audio insert is not guaranteed. Use the host's MIDI Learn to map an external controller to an exposed parameter, and verify Input/Control routing and recorded playback. Do not promise raw MIDI CC support because the generic toolkit has it; this wrapper does not.

## Evidence and remaining checks

Passed: desktop and Force dlopen/lifecycle; earlier 20-control parameter availability declarations; latest desktop tests cover 24 automatable controls and 20 presets; normalized round-trip; option quantization; independent instances; valid/invalid state chunks; bypass; variable blocks and sample rates; all-mode finite audio; Force CPU stress under repeated setParameter calls.

Pending interactive confirmation: discovery as an insert; correct physical knob order on each page; option-list feel; VU movement; touch Learn and + picker; recording/Read playback; project save/reload in MPC itself; FX Rack recall; XY/crossfader/pad/LFO; external MIDI Learn. A DSP benchmark does not prove these UI workflows.

## 22 October Q-Link regression notice

[Maintainer discussion #499](https://github.com/sd88me/mpc-vst-plugins/discussions/499) identifies `audioMasterUpdateDisplay` on every host write as the cause of physical controls snapping back on Track Edit → Automation. The fix is conditional refresh, limited to one per 50 ms; existing binaries require rebuilding. Our float wrapper issues no UpdateDisplay for ordinary knob motion or meters. A Sync transition changes the dependent Time name/value and requests a coalesced refresh, at most once per 50 ms. Preset/state recall also requests one refresh. The converted Time value gets its own host notification. The slow VU uses only its own parameter notification at 20 Hz.

The discussion also reports short option lists and large text-poll costs. Our host readback preserves continuous knob position while quantizing discrete choices in the DSP; this avoids losing tiny hardware increments and retains absolute automation semantics. Tests now run 128 up/down increments on every short option type and assert no refresh for ordinary Time motion and one refresh for a Sync transition. The committed params.lock protects skin indices. No large text polling loop exists.

The thread's claim that MIDI processing is required for automation is a participant's report, not a confirmed host requirement; it does not establish that internal Q-Links are MIDI notes. We retain the native parameter route and the explicit hardware test gate.

Mains hum is intentionally removed, including its harmonic generator. Noise and Tape Age retain random tape texture but cannot restore synthesized 50/60 Hz hum. The old control index is inert and reserved so later control IDs do not shift.

Preview 4 panel: Echo and Character only. Time and Sync pages removed. Legacy timing fields are retained for chunk migration and have no effect on the unified Time workflow. Feedback is remapped: 92% knob = 0.60 original intensity; 98% = 0.75; full travel retains deliberate self-oscillation. Display-only reel slot 27 is excluded from automation and Q-Links.

Preview 5: inactive sections are gray, marked OFF and have no touch actions. Reverb Level/Pan ignore changes in tape-only modes; echo Time/Sync, Feedback, Echo Level/Pan, Bass/Treble, Wow/Flutter, Tape Age/Hiss and Tape Input ignore changes in Spring Only. Stored values are retained. Tape Heads and shared Drive/Mix/Output/Dry controls remain active. Read-only section flags 28/29 update only when the selected head mode changes or state is recalled.

Preview 6 panel: both Echo and Character tabs have identically positioned Sync and Feed Input metal switches, with no On/Off captions. No Bypass/Unit Power switch appears on the panel; use the Force insert bypass. The saved bypass parameter is retained for host compatibility.
