# Magic Tape Echo

A native stereo tape echo for **Akai Force and Gen1 MPC**, based on Dusk Audio's **Tape Echo 2 v1.0.8**. Three playback heads, tape saturation, wow/flutter, tape-age settings, tempo sync, optional spring reverb, and a slow, smooth needle VU on a vintage cream-and-green panel.

![Magic Tape Echo panel](docs/panel-0.png)

**0.1.0-preview.8 — extended-timing host tests passed; current build hardware validation pending.** Requires the community native VST2 installation route and root access. This is not a stock-firmware drag-and-drop VST3. No Gen2/aarch64 build or hardware verification is claimed. MPC 2.x skins have not been validated; the current skin targets 3.x.

## CPU first

Earlier 21-parameter build: real Force / ARMv7 measurements at 44.1 kHz, 128 samples, with the VU enabled:

| Test | Measured cost |
|---|---:|
| Tape-only, dedicated host test | 7.52% of one core (average) |
| Three heads + spring, dedicated host test | 14.83% of one core (average) |
| Bypass, dedicated host test | 0.056% of one core (average) |
| Standard audio-input stress stage | 8.2% average / 8.8% p99 |
| Every-parameter sweep | 17.2% p99 / 17.5% maximum block |

These are fractions of **one CPU core's audio-block budget**, not the Force's total CPU meter. The standard community benchmark gives **WARN**, because the automated sweep exceeds its conservative 15% p99 PASS threshold; it remains far below a full block. Start with one instance in a busy project. Full spring reverb is the expensive option. Device logs are in [docs/force-benchmark.txt](docs/force-benchmark.txt).

The default is tape-only. An inaudible spring tank sleeps, and fully bypassed processing takes a fast copy path. No desktop GUI, oversampling wrapper, extra audio bridge, worker thread, or 16-bit conversion. The original engine's internal preamp oversampling is retained. ARMv7 flush-to-zero prevents denormal slowdowns. All DSP storage is allocated on activation; the audio path uses fixed storage and lock-free control values.

## Controls and automation

All Dusk input parameters except the deliberately removed mains hum are represented, plus Sync Mapping, extended Time and Timing Range: **24 automatable controls**. VU and Peak are separate read-only parameters. Two touchscreen/Q-Link pages: **Echo** and **Character**. A metal Sync switch beside the animated reels changes the single Time knob between milliseconds and notes. The meter refreshes at 20 Hz, with additional 150 ms attack / 450 ms release smoothing over the original record meter. A separate Peak lamp accompanies the average VU.

Read [Q-Links, macros and automation](docs/CONTROL.md) for exact assignments, Force Learn/+ workflows, FX Rack restrictions, MIDI routing distinctions, and an on-device validation checklist. Host-based automation is block-rate, with the upstream smoothing and tape-motor inertia. Do not assume sample-accurate automation or that a passed setter test proves macro recording.

## Install

Download the `Magic-Tape-Echo-0.1.0-preview.8-mpc-armv7.zip` package, extract it, and follow its `INSTALL.md`. The included installer backs up MPC settings, registers this as an **effect**, and restarts MPC. Save your project first. An uninstaller is included. The port does not modify firmware or replace a stock plugin.

For an aux/send effect, set Mix to 100%. For an insert, start with the default 35%. Mix uses the upstream unity-overlap law, not a constant-power crossfade. Input Drive and Output at 50% are their calibrated unity settings. Feedback now spreads ordinary repeats across the first 92% of knob travel; the top end deliberately allows self-oscillation. The factory bank avoids that top region.

## Build and test

The DSP is vendored; the native host build needs Python 3 and a C++17 compiler:

```sh
bash build.sh host
# ARM hard-float compiler against glibc <= 2.31 recommended:
bash build.sh armv7
```

ARM build tested with `arm-linux-gnueabihf-g++` in Debian Bullseye, Cortex-A17/NEON flags, static C++ runtime; highest required glibc symbol is 2.27. No `-ffast-math` is used.

Skin/package tools are external and pinned to `sd88me/mpc-vst-plugins` commit `97a2effca4114dd00f738b018e2f0d1d3ccb2d7f`. Set `MPC_VST` to that checkout. Install Pillow, Playwright and its Chromium renderer in your build environment, then run `bash tools/skin.sh` and `bash tools/package.sh` after the ARM build. Chromium runs only to render assets during development; it is not shipped or used on the Force.

Native tests cover lifecycle, 24 automatable controls, 20 presets, state validation, independent instances, bypass, all head modes, 44.1/48/96 kHz, and variable blocks. Timing tests measure actual four-bar audio arrivals for each leading head at 20 and 120 BPM, validate all 42 divisions, and test nearest-note conversion at the current host tempo. Earlier ASan/UBSan and original-core comparisons predate the long-delay change; interactive Force validation remains pending.

## Time and presets

 the same Time knob shows milliseconds with Sync off and note lengths with Sync on. Turning Sync on chooses the nearest duration at the last valid host BPM (120 until the host supplies tempo); turning it off converts that note back to milliseconds. D = dotted (×1.5), T = triplet (×2/3), Q = quintuplet (×4/5). There are 42 choices from 1/128 tuplets through four bars, with bars defined as 4/4. Free time spans 1–48,000 ms. At 120 BPM four bars is 8,000 ms; at 20 BPM it is 48,000 ms.

Timing targets the leading active head; later heads retain the original spacing and can sound beyond four bars. The modeled transport still has subtle pitch movement and inertia. Long spacing keeps the original usable tape bandwidth rather than reducing it below audibility. A single mono tape ring reserves 32 MiB at 44.1/48 kHz (higher sample rates use more); reset invalidates old samples without clearing the large ring in the audio callback.

Old timing indices are retained for saved-state compatibility, but are not on the panel. Earlier Original-timing chunks are converted into the single Time control on recall.

Twenty complete factory programs are built into the VST and defined in `vst/presets.json`, including slapback, dub, spring, worn tape, triplets, quintuplets, and two/four-bar delays. Preset and project recall restore stored Time exactly, without running the user-toggle conversion. All factory presets use the single Time control.

## Provenance

GPL-3.0-or-later. Dusk Audio owns the upstream DSP; MagicStino supplies this Force/MPC port and panel. See [src/VENDORED.md](src/VENDORED.md). No affiliation with Akai, inMusic, or Dusk Audio is implied.

Mains hum is intentionally removed, including its harmonic generator. Noise and Tape Age retain random tape texture but cannot restore synthesized 50/60 Hz hum. The old control index is inert and reserved so later control IDs do not shift.

Preview 4: VU is calibrated to 0 VU = -18 dBFS RMS, with automatic movement and a separate PEAK lamp. The earlier scale held ordinary low-level signals at zero. Tape reels use a 12-frame strip at capped update rate and stop in bypass. Tests verify three input levels, meter decay/notifications and decaying tails at 90% Feedback across all 12 modes under the tested settings; extreme drive/EQ may still sustain feedback.

Preview 5: inactive sections are gray, marked OFF and have no touch actions. Reverb Level/Pan ignore changes in tape-only modes; echo Time/Sync, Feedback, Echo Level/Pan, Bass/Treble, Wow/Flutter, Tape Age/Hiss and Tape Input ignore changes in Spring Only. Stored values are retained. Tape Heads and shared Drive/Mix/Output/Dry controls remain active. Read-only section flags 28/29 update only when the selected head mode changes or state is recalled.

Preview 6 panel: both Echo and Character tabs have identically positioned Sync and Feed Input metal switches, with no On/Off captions. No Bypass/Unit Power switch appears on the panel; use the Force insert bypass. The saved bypass parameter is retained for host compatibility.

Preview 7 adds a tiny green LED beside Sync and Feed Input on both tabs. The LED is dark when the switch is off or the tape section is unavailable. LEDs are passive native image strips bound to existing parameters; no new audio processing or polling.
